export const gender = ['male', 'female'];
export const userRole = ['admin', 'student'];

export const userFilterableFields = [
  'searchTerm',
  'email',
  'phoneNumber',
  'studentId',
  'role',
  'isValid',
  'userStatus',
];

export const userSearchableFields = ['email', 'phoneNumber', 'studentId'];
