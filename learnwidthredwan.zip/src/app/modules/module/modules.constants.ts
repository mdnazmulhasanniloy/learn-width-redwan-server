export const ModuleFilterableFields = [
  'id',
  'moduleName',
  'courseName',
  'batchName',
  'searchTerm',
];

export const moduleSearchableFields = [
  'id',
  'moduleName',
  'courseName',
  'batchName',
];
