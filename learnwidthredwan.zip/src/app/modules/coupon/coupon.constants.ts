export const couponSearchableFields = [
  'discount',
  'expireAt',
  'couponCode',
  'couponLabel',
];

export const couponFilterableFields = [
  'discount',
  'expireAt',
  'couponCode',
  'couponLabel',
  'searchTerm',
];
