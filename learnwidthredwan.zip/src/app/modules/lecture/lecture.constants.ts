export const lectureFilterableFields = [
  'id',
  'type',
  'batch',
  'module',
  'course',
  'lectureName',
  'searchTerm',
];

export const lectureSearchableFields = [
  'id',
  'LectureName',
  'id',
  'type',
  'batch',
];
