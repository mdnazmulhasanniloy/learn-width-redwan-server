export const courseFilterableFields = [
  'id',
  'name',
  'duration',
  'regularPrice',
  'currentBatch',
  'searchTerm',
];

export const courseSearchableFields = ['id', 'name', 'currentBatch'];
