export const batchFilterableFields = [
  'id',
  'name',
  'duration',
  'startedAt',
  'courseId',
  'searchTerm',
];

export const batchSearchableFields = ['id', 'name', 'courseId', 'startAt'];
