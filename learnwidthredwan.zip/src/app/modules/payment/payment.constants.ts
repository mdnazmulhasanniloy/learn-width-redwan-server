export const PaymentStatus = ['pending', 'paid'];
