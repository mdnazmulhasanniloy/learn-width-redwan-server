export const enum ENUM_USER_ROLE {
  ADMIN = 'admin',
  STUDENT = 'student',
}
