type IGenericErrorMessage = {
  path: string;
  message: string;
};

export { IGenericErrorMessage };
